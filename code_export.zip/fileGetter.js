// fileGetter.js

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Definiowanie __dirname w modułach ES
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function readFiles(fileList) {
    const filesContent = {};
    fileList.forEach((filePath) => {
        const absolutePath = path.resolve(__dirname, filePath);
        if (fs.existsSync(absolutePath)) {
            try {
                const content = fs.readFileSync(absolutePath, 'utf-8');
                filesContent[filePath] = content;
            } catch (err) {
                console.error(`Błąd podczas czytania pliku ${filePath}: ${err}`);
            }
        } else {
            console.error(`Plik ${filePath} nie został znaleziony.`);
        }
    });
    return filesContent;
}

function saveToFile(filesContent, outputFileName) {
    const allContent = Object.entries(filesContent)
        .map(([filePath, content]) => `--- Zawartość pliku: ${filePath} ---\n${content}\n`)
        .join('\n');

    fs.writeFileSync(outputFileName, allContent, 'utf-8');
    console.log(`Zawartość plików została zapisana do '${outputFileName}'.`);
}

function main() {
    const args = process.argv.slice(2);
    if (args.length < 2) {
        console.log("Użycie: node fileGetter.js nazwa_pliku_wynikowego nazwa_pliku [dodatkowe_pliki...]");
        process.exit(1);
    }

    const outputFileName = args[0];
    const fileList = args.slice(1);

    const filesContent = readFiles(fileList);
    saveToFile(filesContent, outputFileName);
}

main();
