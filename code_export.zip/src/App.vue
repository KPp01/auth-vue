<template>
  <div id="app" :class="{ 'dark-mode': isDarkMode }">
    <NavigationBar @toggle-theme="toggleTheme" />
    <main class="app-content">
      <router-view v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>
    <Toast position="bottom-right" />
  </div>
</template>

<script>
import { ref, provide, computed } from 'vue';
import { useStore } from 'vuex';
import NavigationBar from './components/NavigationBar.vue'; // Upewnij się, że ścieżka jest poprawna
import Toast from 'primevue/toast';

export default {
  name: 'App',
  components: {
    NavigationBar,
    Toast
  },
  setup() {
    const store = useStore();
    const isDarkMode = ref(localStorage.getItem('theme') === 'dark');

    const toggleTheme = () => {
      isDarkMode.value = !isDarkMode.value;
      localStorage.setItem('theme', isDarkMode.value ? 'dark' : 'light');
      document.documentElement.setAttribute('data-theme', isDarkMode.value ? 'dark' : 'light');
    };

    const user = computed(() => store.state.user);

    provide('isDarkMode', isDarkMode);
    provide('user', user);

    return {
      isDarkMode,
      toggleTheme
    };
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.app-content {
  flex: 1;
  padding: 20px;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>