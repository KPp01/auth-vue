<template>
  <div class="dashboard-ai">
    <h1>{{ $t('aiDashboard.title') }}</h1>
    <p>{{ $t('aiDashboard.description') }}</p>

    <div class="dashboard-content">
      <div class="main-panel">
        <ModelSelector v-model="selectedModel" @update:model-value="handleModelChange" />

        <CommandInput
          v-model="command"
          :maxTokens="maxTokens"
          :temperature="temperature"
          @update:max-tokens="maxTokens = $event"
          @update:temperature="temperature = $event"
          @submit="sendCommand"
        />

        <CommandEvaluator
          :command="command"
          :model="selectedModel"
          @evaluation-complete="handleEvaluation"
        />

        <Button
          :label="isProcessing ? $t('aiDashboard.processing') : $t('aiDashboard.generateResponse')"
          @click="sendCommand"
          :disabled="!command || isProcessing"
          :loading="isProcessing"
          class="send-button p-button-primary"
        />

        <ResponseViewer
          v-if="response"
          :response="response"
          :model="selectedModel"
          @copy="copyToClipboard"
        />

        <ResponseEvaluator
          v-if="response"
          :response="response"
          :originalQuery="command"
          @evaluation-complete="handleResponseEvaluation"
        />

        <ResponseFormatter
          v-if="response"
          :response="response"
          @format-changed="handleFormatChange"
        />

        <SemanticAnalyzer
          v-if="response"
          :text="response"
          @analysis-complete="handleSemanticAnalysis"
        />
      </div>

      <div class="side-panel">
        <ResponseTimeline :responseEvents="responseEvents" />

        <InteractiveExamples
          :initialExamples="interactiveExamples"
          @example-run="handleExampleRun"
        />

        <ResponseComparator
          v-if="previousResponse"
          :responseA="previousResponse"
          :responseB="response"
        />

        <CommandHistory
          :history="history"
          @clear-history="clearCommandHistory"
          @select-command="selectHistoricalCommand"
        />

        <HistoryAnalysis :analysisData="historyAnalysis" />

        <ExportManager
          :data="exportData"
          @export-complete="handleExportComplete"
        />
      </div>
    </div>

    <LanguageTranslator
      v-if="response"
      :text="response"
      @translation-complete="handleTranslation"
    />

    <TextToSpeech
      v-if="response"
      :text="response"
      @speech-complete="handleSpeechSynthesis"
    />

    <AIDebugger :debugInfo="debugInfo" />

    <Toast />
  </div>
</template>

<script>
import { ref, computed, onMounted, watch } from 'vue';
import { useI18n } from 'vue-i18n';
import { useAIStore } from '@/stores/aiStore';
import { useThreadStore } from '@/stores/threadStore';
import { useTranslationStore } from '@/stores/translationStore';
import { useTextToSpeechStore } from '@/stores/textToSpeechStore';
import { useNotificationStore } from '@/stores/notificationStore';
import ModelSelector from '@/components/modulesAI/ModelSelector.vue';
import CommandInput from '@/components/modulesAI/CommandInput.vue';
import CommandEvaluator from '@/components/modulesAI/CommandEvaluator.vue';
import ResponseViewer from '@/components/modulesAI/ResponseViewer.vue';
import ResponseEvaluator from '@/components/modulesAI/ResponseEvaluator.vue';
import ResponseFormatter from '@/components/modulesAI/ResponseFormatter.vue';
import SemanticAnalyzer from '@/components/modulesAI/SemanticAnalyzer.vue';
import ResponseTimeline from '@/components/modulesAI/ResponseTimeline.vue';
import InteractiveExamples from '@/components/modulesAI/InteractiveExamples.vue';
import ResponseComparator from '@/components/modulesAI/ResponseComparator.vue';
import CommandHistory from '@/components/modulesAI/CommandHistory.vue';
import HistoryAnalysis from '@/components/modulesAI/HistoryAnalysis.vue';
import ExportManager from '@/components/modulesAI/ExportManager.vue';
import LanguageTranslator from '@/components/modulesAI/LanguageTranslator.vue';
import TextToSpeech from '@/components/modulesAI/TextToSpeech.vue';
import AIDebugger from '@/components/modulesAI/AIDebugger.vue';
import Button from 'primevue/button';
import Toast from 'primevue/toast';
import { useToast } from 'primevue/usetoast';

export default {
  name: 'DashboardAi',
  components: {
    ModelSelector,
    CommandInput,
    CommandEvaluator,
    ResponseViewer,
    ResponseEvaluator,
    ResponseFormatter,
    SemanticAnalyzer,
    ResponseTimeline,
    InteractiveExamples,
    ResponseComparator,
    CommandHistory,
    HistoryAnalysis,
    ExportManager,
    LanguageTranslator,
    TextToSpeech,
    AIDebugger,
    Button,
    Toast
  },
  setup() {
    const { t } = useI18n();
    const toast = useToast();
    const aiStore = useAIStore();
    const threadStore = useThreadStore();
    const translationStore = useTranslationStore();
    const ttsStore = useTextToSpeechStore();
    const notificationStore = useNotificationStore();

    const command = ref('');
    const response = ref('');
    const previousResponse = ref('');
    const maxTokens = ref(1000);
    const temperature = ref(0.7);
    const responseEvents = ref([]);
    const interactiveExamples = ref([]);
    const debugInfo = ref({});
    const isProcessing = ref(false);

    const selectedModel = computed(() => aiStore.selectedModel);
    const history = computed(() => threadStore.currentThread?.messages || []);
    const historyAnalysis = computed(() => aiStore.analyzeConversationTrends());
    const exportData = computed(() => ({
      command: command.value,
      response: response.value,
      model: selectedModel.value,
      timestamp: new Date().toISOString(),
    }));

    onMounted(async () => {
      try {
        await aiStore.initializeConversation('New Conversation');
        await ttsStore.loadVoices();
        loadInteractiveExamples();
      } catch (error) {
        console.error('Initialization error:', error);
        notificationStore.showNotification({
          type: 'error',
          message: t('notifications.initializationError')
        });
      }
    });

    const sendCommand = async () => {
      if (!command.value || isProcessing.value) return;

      isProcessing.value = true;
      responseEvents.value.push({
        title: t('aiDashboard.commandSent'),
        description: t('aiDashboard.commandSentDescription'),
        timestamp: new Date()
      });

      try {
        previousResponse.value = response.value;
        response.value = await aiStore.sendMessage(command.value);

        responseEvents.value.push({
          title: t('aiDashboard.responseReceived'),
          description: t('aiDashboard.responseReceivedDescription'),
          timestamp: new Date()
        });

        notificationStore.showNotification({
          type: 'success',
          message: t('notifications.responseGenerated')
        });
      } catch (error) {
        console.error('Error sending command:', error);
        debugInfo.value = { ...debugInfo.value, error: error.message };
        notificationStore.showNotification({
          type: 'error',
          message: t('notifications.commandError')
        });
      } finally {
        isProcessing.value = false;
      }
    };

    const clearCommandHistory = () => {
      threadStore.clearHistory();
      notificationStore.showNotification({
        type: 'info',
        message: t('notifications.historyCleared')
      });
    };

    const selectHistoricalCommand = (historicalCommand) => {
      command.value = historicalCommand;
    };

    const handleModelChange = (newModel) => {
      aiStore.setSelectedModel(newModel);
      notificationStore.showNotification({
        type: 'info',
        message: t('notifications.modelChanged', { model: newModel })
      });
    };

    const handleEvaluation = (evaluation) => {
      debugInfo.value = { ...debugInfo.value, commandEvaluation: evaluation };
    };

    const handleResponseEvaluation = (evaluation) => {
      debugInfo.value = { ...debugInfo.value, responseEvaluation: evaluation };
    };

    const handleFormatChange = (formattedResponse) => {
      response.value = formattedResponse;
    };

    const handleSemanticAnalysis = (analysis) => {
      debugInfo.value = { ...debugInfo.value, semanticAnalysis: analysis };
    };

    const handleExportComplete = (exportedData) => {
      console.log('Export completed:', exportedData);
      notificationStore.showNotification({
        type: 'success',
        message: t('notifications.exportComplete')
      });
    };

    const handleTranslation = (translation) => {
      debugInfo.value = { ...debugInfo.value, translation };
    };

    const handleSpeechSynthesis = (speechInfo) => {
      debugInfo.value = { ...debugInfo.value, speechSynthesis: speechInfo };
    };

    const handleExampleRun = async (example) => {
      command.value = example.command;
      await sendCommand();
    };

    const loadInteractiveExamples = () => {
      // W rzeczywistej aplikacji, te przykłady mogłyby być pobierane z API
      interactiveExamples.value = [
        { id: 1, command: t('aiDashboard.exampleCommand1'), description: t('aiDashboard.exampleDescription1') },
        { id: 2, command: t('aiDashboard.exampleCommand2'), description: t('aiDashboard.exampleDescription2') },
      ];
    };

    const copyToClipboard = (text) => {
      navigator.clipboard.writeText(text).then(() => {
        notificationStore.showNotification({
          type: 'success',
          message: t('notifications.textCopied')
        });
      }).catch(err => {
        console.error('Failed to copy text: ', err);
        notificationStore.showNotification({
          type: 'error',
          message: t('notifications.copyFailed')
        });
      });
    };

    watch(selectedModel, (newModel, oldModel) => {
      if (newModel !== oldModel) {
        notificationStore.showNotification({
          type: 'info',
          message: t('notifications.modelChanged', { model: newModel })
        });
      }
    });

    return {
      command,
      response,
      previousResponse,
      maxTokens,
      temperature,
      responseEvents,
      interactiveExamples,
      debugInfo,
      isProcessing,
      selectedModel,
      history,
      historyAnalysis,
      exportData,
      sendCommand,
      clearCommandHistory,
      selectHistoricalCommand,
      handleModelChange,
      handleEvaluation,
      handleResponseEvaluation,
      handleFormatChange,
      handleSemanticAnalysis,
      handleExportComplete,
      handleTranslation,
      handleSpeechSynthesis,
      handleExampleRun,
      copyToClipboard
    };
  }
};
</script>

<style scoped>
.dashboard-ai {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  font-family: var(--font-family);
}

h1 {
  color: var(--text-color);
  text-align: center;
  margin-bottom: 1rem;
}
p {
  text-align: center;
  color: var(--text-color-secondary);
  margin-bottom: 2rem;
}

.dashboard-content {
  display: flex;
  gap: 2rem;
}

.main-panel {
  flex: 2;
}

.side-panel {
  flex: 1;
}

.send-button {
  width: 100%;
  margin-top: 1rem;
  margin-bottom: 1rem;
}

@media (max-width: 1024px) {
  .dashboard-content {
    flex-direction: column;
  }

  .main-panel,
  .side-panel {
    width: 100%;
  }
}

/* Stylizacja komponentów */
:deep(.p-card) {
  margin-bottom: 1rem;
  background-color: var(--surface-a);
  border: 1px solid var(--surface-d);
}

:deep(.p-card .p-card-title) {
  color: var(--text-color);
  font-size: 1.2rem;
}

:deep(.p-card .p-card-content) {
  padding: 1rem;
}

:deep(.p-inputtext) {
  width: 100%;
}

:deep(.p-dropdown) {
  width: 100%;
}

/* Animacje */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.slide-fade-enter-active {
  transition: all 0.3s ease-out;
}

.slide-fade-leave-active {
  transition: all 0.3s cubic-bezier(1, 0.5, 0.8, 1);
}

.slide-fade-enter-from,
.slide-fade-leave-to {
  transform: translateY(20px);
  opacity: 0;
}

/* Dostosowania dla trybu ciemnego */
:deep([data-theme="dark"]) .dashboard-ai {
  background-color: var(--surface-a);
}

:deep([data-theme="dark"]) .p-card {
  background-color: var(--surface-b);
}

:deep([data-theme="dark"]) .p-inputtext,
:deep([data-theme="dark"]) .p-dropdown {
  background-color: var(--surface-c);
  color: var(--text-color);
}

/* Poprawki dostępności */
:deep(.p-button) {
  font-weight: bold;
}

:deep(.p-inputtext:focus),
:deep(.p-dropdown:focus) {
  box-shadow: 0 0 0 2px var(--primary-color);
}

/* Stylizacja scrollbara dla lepszej spójności */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

::-webkit-scrollbar-track {
  background: var(--surface-b);
}

::-webkit-scrollbar-thumb {
  background-color: var(--primary-color);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background-color: var(--primary-color-text);
}
</style>