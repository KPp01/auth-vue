// src/components/modulesAI/CommandEvaluator.js
import { tokenize } from '@/utils/tokenizer';
import { analyzeComplexity } from '@/utils/complexityAnalysis';

export function evaluateCommand(command, model) {
  const tokens = tokenize(command);
  const complexity = analyzeComplexity(command);

  const evaluation = {
    tokenCount: tokens.length,
    complexity: complexity,
    suitability: calculateSuitability(tokens.length, complexity, model),
    suggestions: []
  };

  if (evaluation.tokenCount > getModelMaxTokens(model)) {
    evaluation.suggestions.push('Consider shortening the command to fit within model token limits.');
  }

  if (evaluation.complexity === 'Low' && model.includes('gpt-4')) {
    evaluation.suggestions.push('This command might be better suited for a simpler model like GPT-3.5-turbo.');
  }

  if (evaluation.complexity === 'High' && !model.includes('gpt-4')) {
    evaluation.suggestions.push('Consider using a more advanced model like GPT-4 for this complex query.');
  }

  return evaluation;
}

function calculateSuitability(tokenCount, complexity, model) {
  // Implement suitability calculation logic
  // Return a value between 0 and 1
}

function getModelMaxTokens(model) {
  // Return max tokens for the given model
  // This should be updated as model capabilities change
}