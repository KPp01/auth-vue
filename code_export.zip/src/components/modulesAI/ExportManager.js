// src/components/modulesAI/ExportManager.js
import { saveAs } from 'file-saver';

export default {
  exportToJSON(data, filename = 'export.json') {
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    saveAs(blob, filename);
  },

  exportToCSV(data, filename = 'export.csv') {
    const csvContent = this.convertToCSV(data);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    saveAs(blob, filename);
  },

  exportToPDF(data, filename = 'export.pdf') {
    // Implement PDF export logic
    // This might require a library like pdfmake
    console.log('PDF export not implemented yet');
  },

  convertToCSV(objArray) {
    const array = typeof objArray !== 'object' ? JSON.parse(objArray) : objArray;
    let str = '';
    for (let i = 0; i < array.length; i++) {
      let line = '';
      for (const index in array[i]) {
        if (line !== '') line += ',';
        line += array[i][index];
      }
      str += line + '\r\n';
    }
    return str;
  }
};