<template>
    <div class="response-time-graph">
      <p>Response Time Graph Placeholder</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'ResponseTimeGraph',
    props: {
      responseTimes: Array
    }
  }
  </script>