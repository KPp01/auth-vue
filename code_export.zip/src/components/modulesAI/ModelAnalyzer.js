const modelCapabilities = {
  'gpt-3.5-turbo': {
    maxTokens: 4096,
    capabilities: ['generalQuery', 'codeGeneration', 'summarization'],
    strengths: ['Fast responses', 'Good for general tasks'],
    weaknesses: ['Limited context understanding', 'May struggle with complex reasoning'],
  },
  'gpt-4': {
    maxTokens: 8192,
    capabilities: ['generalQuery', 'codeGeneration', 'dataAnalysis', 'complexReasoning'],
    strengths: ['Advanced reasoning', 'Better context understanding', 'More coherent long-form content'],
    weaknesses: ['Slower than GPT-3.5', 'Higher cost'],
  },
  'chatgpt-4o-latest': {
    maxTokens: 128000, // Aktualizuj na bieżąco
    capabilities: ['generalQuery', 'codeGeneration', 'dataAnalysis', 'complexReasoning', 'imageProcessing'],
    strengths: ['Bardzo duży kontekst', 'Najnowsza wersja modelu', 'Wielomodalność'],
    weaknesses: ['Niezalecany do zastosowań produkcyjnych', 'Może się zmieniać bez ostrzeżenia'],
  },
  'gpt-4o-mini': {
    maxTokens: 128000,
    capabilities: ['generalQuery', 'codeGeneration', 'fastProcessing', 'imageProcessing'],
    strengths: ['Szybkie odpowiedzi', 'Niski koszt', 'Dobry stosunek możliwości do ceny'],
    weaknesses: ['Mniej zaawansowany niż pełne modele GPT-4', 'Może nie radzić sobie z bardzo złożonymi zadaniami'],
  },
};

export function getModelCapabilities(model) {
  return modelCapabilities[model] || {
    maxTokens: 1024,
    capabilities: ['generalQuery'],
    strengths: ['Unknown'],
    weaknesses: ['Unknown'],
  };
}

export function recommendModel(intent, complexity, tokenCount) {
  if (complexity === 'High' && tokenCount > 4000) {
    return 'gpt-4';
  } else if (intent === 'CODE_GENERATION' || intent === 'DATA_ANALYSIS') {
    return tokenCount > 2000 ? 'gpt-4' : 'gpt-3.5-turbo';
  } else if (intent === 'GENERAL_QUERY' && complexity === 'Low') {
    return 'gpt-4o-mini';
  } else {
    return 'gpt-3.5-turbo';
  }
}

export function estimateCost(model, tokenCount) {
  const costPerToken = {
    'gpt-3.5-turbo': 0.000002,
    'gpt-4': 0.00003,
    'chatgpt-4o-latest': 0.00005, // Przykładowa cena, zaktualizuj
    'gpt-4o-mini': 0.000001, // Przykładowa cena, zaktualizuj
  };

  return (costPerToken[model] || 0) * tokenCount;
}