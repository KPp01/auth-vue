// src/components/modulesAI/SemanticAnalyzer.js
import natural from 'natural';
import { stopwords } from '@/utils/stopwords';

const tokenizer = new natural.WordTokenizer();
const TfIdf = natural.TfIdf;
const tfidf = new TfIdf();

export function analyzeSemantics(text) {
  const tokens = tokenizer.tokenize(text.toLowerCase());
  const filteredTokens = tokens.filter(token => !stopwords.includes(token));
  
  tfidf.addDocument(filteredTokens);

  const keyTerms = getKeyTerms(tfidf, 5);
  const sentiment = analyzeSentiment(text);
  const entities = extractEntities(text);
  const topics = identifyTopics(filteredTokens);

  return {
    keyTerms,
    sentiment,
    entities,
    topics,
    wordCount: tokens.length,
    uniqueWords: new Set(tokens).size,
  };
}

function getKeyTerms(tfidf, numTerms) {
  return tfidf.listTerms(0 /*document index*/).slice(0, numTerms);
}

function analyzeSentiment(text) {
  const analyzer = new natural.SentimentAnalyzer('English', natural.PorterStemmer, 'afinn');
  const sentiment = analyzer.getSentiment(tokenizer.tokenize(text));
  
  if (sentiment > 0.05) return 'Positive';
  if (sentiment < -0.05) return 'Negative';
  return 'Neutral';
}

function extractEntities(text) {
  const language = "EN";
  const classifier = new natural.BrillPOSTagger(language);
  const tokenized = tokenizer.tokenize(text);
  const tagged = classifier.tag(tokenized);

  return tagged.taggedWords
    .filter(word => word.tag.startsWith('N') || word.tag.startsWith('J'))
    .map(word => word.token);
}

function identifyTopics(tokens) {
  // This is a simple topic identification. For more advanced topic modeling,
  // consider using libraries like lda.js or implementing LDA algorithm.
  const topics = {};
  tokens.forEach(token => {
    if (token.length > 3) {  // Ignore very short words
      topics[token] = (topics[token] || 0) + 1;
    }
  });

  return Object.entries(topics)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([topic, count]) => ({ topic, count }));
}

export function compareSemantics(text1, text2) {
  const analysis1 = analyzeSemantics(text1);
  const analysis2 = analyzeSemantics(text2);

  const commonKeyTerms = analysis1.keyTerms.filter(term => 
    analysis2.keyTerms.some(t => t.term === term.term)
  );

  const topicSimilarity = calculateTopicSimilarity(analysis1.topics, analysis2.topics);

  return {
    commonKeyTerms,
    sentimentComparison: {
      text1: analysis1.sentiment,
      text2: analysis2.sentiment,
    },
    topicSimilarity,
    entityOverlap: calculateEntityOverlap(analysis1.entities, analysis2.entities),
  };
}

function calculateTopicSimilarity(topics1, topics2) {
  const allTopics = new Set([...topics1.map(t => t.topic), ...topics2.map(t => t.topic)]);
  let similarity = 0;

  allTopics.forEach(topic => {
    const count1 = topics1.find(t => t.topic === topic)?.count || 0;
    const count2 = topics2.find(t => t.topic === topic)?.count || 0;
    similarity += Math.min(count1, count2) / Math.max(count1, count2);
  });

  return similarity / allTopics.size;
}

function calculateEntityOverlap(entities1, entities2) {
  const set1 = new Set(entities1);
  const set2 = new Set(entities2);
  const intersection = new Set([...set1].filter(x => set2.has(x)));
  return intersection.size / Math.max(set1.size, set2.size);
}