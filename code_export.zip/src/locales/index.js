import en from './en.json';
import pl from './pl.json';

export default {
  en,
  pl
};