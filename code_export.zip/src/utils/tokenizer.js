import natural from 'natural';

const tokenizer = new natural.WordTokenizer();
const stemmer = natural.PorterStemmer;

export function tokenize(text, options = {}) {
  const {
    lowercase = true,
    removeStopwords = true,
    stem = false,
    removePunctuation = true,
  } = options;

  let processedText = text;

  if (lowercase) {
    processedText = processedText.toLowerCase();
  }

  if (removePunctuation) {
    processedText = processedText.replace(/[^\w\s]|_/g, "").replace(/\s+/g, " ");
  }

  let tokens = tokenizer.tokenize(processedText);

  if (removeStopwords) {
    const stopwords = new Set(natural.stopwords);
    tokens = tokens.filter(token => !stopwords.has(token));
  }

  if (stem) {
    tokens = tokens.map(token => stemmer.stem(token));
  }

  return tokens;
}

export function calculateTokenFrequency(tokens) {
  return tokens.reduce((freq, token) => {
    freq[token] = (freq[token] || 0) + 1;
    return freq;
  }, {});
}

export function getTopNTokens(tokens, n = 10) {
  const freq = calculateTokenFrequency(tokens);
  return Object.entries(freq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([token, frequency]) => ({ token, frequency }));
}

export function estimateTokenCount(text) {
  // Przybliżone oszacowanie liczby tokenów dla modeli GPT
  return Math.ceil(text.length / 4);
}