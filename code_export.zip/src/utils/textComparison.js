import { tokenize } from './tokenizer';
import natural from 'natural';

const TfIdf = natural.TfIdf;

export function calculateSimilarity(text1, text2) {
  const tokens1 = tokenize(text1);
  const tokens2 = tokenize(text2);

  const jaccardSimilarity = calculateJaccardSimilarity(tokens1, tokens2);
  const cosineSimilarity = calculateCosineSimilarity(text1, text2);
  const levenshteinDistance = natural.LevenshteinDistance(text1, text2);
  const normalizedLevenshteinSimilarity = 1 - (levenshteinDistance / Math.max(text1.length, text2.length));

  return {
    jaccardSimilarity: jaccardSimilarity.toFixed(4),
    cosineSimilarity: cosineSimilarity.toFixed(4),
    levenshteinDistance,
    normalizedLevenshteinSimilarity: normalizedLevenshteinSimilarity.toFixed(4),
    averageSimilarity: ((jaccardSimilarity + cosineSimilarity + normalizedLevenshteinSimilarity) / 3).toFixed(4),
    commonWords: findCommonWords(tokens1, tokens2),
    uniqueWords: {
      text1: findUniqueWords(tokens1, tokens2),
      text2: findUniqueWords(tokens2, tokens1)
    }
  };
}

function calculateJaccardSimilarity(tokens1, tokens2) {
  const set1 = new Set(tokens1);
  const set2 = new Set(tokens2);
  const intersection = new Set([...set1].filter(x => set2.has(x)));
  const union = new Set([...set1, ...set2]);
  return intersection.size / union.size;
}

function calculateCosineSimilarity(text1, text2) {
  const tfidf = new TfIdf();
  tfidf.addDocument(text1);
  tfidf.addDocument(text2);

  const vector1 = tfidf.listTerms(0);
  const vector2 = tfidf.listTerms(1);

  let dotProduct = 0;
  let magnitude1 = 0;
  let magnitude2 = 0;

  vector1.forEach(term => {
    const idx = vector2.findIndex(t => t.term === term.term);
    if (idx !== -1) {
      dotProduct += term.tfidf * vector2[idx].tfidf;
    }
    magnitude1 += term.tfidf * term.tfidf;
  });

  vector2.forEach(term => {
    magnitude2 += term.tfidf * term.tfidf;
  });

  magnitude1 = Math.sqrt(magnitude1);
  magnitude2 = Math.sqrt(magnitude2);

  return dotProduct / (magnitude1 * magnitude2);
}

function findCommonWords(tokens1, tokens2) {
  const set1 = new Set(tokens1);
  const set2 = new Set(tokens2);
  return [...set1].filter(x => set2.has(x));
}

function findUniqueWords(tokens1, tokens2) {
  const set1 = new Set(tokens1);
  const set2 = new Set(tokens2);
  return [...set1].filter(x => !set2.has(x));
}

export function analyzeSimilarityTrends(texts) {
  const similarities = [];
  for (let i = 0; i < texts.length - 1; i++) {
    similarities.push(calculateSimilarity(texts[i], texts[i + 1]));
  }

  const averageSimilarity = similarities.reduce((sum, sim) => sum + parseFloat(sim.averageSimilarity), 0) / similarities.length;
  const similarityTrend = similarities.map((sim, index) => ({
    pairIndex: index,
    averageSimilarity: sim.averageSimilarity,
    trend: index > 0 ? (parseFloat(sim.averageSimilarity) > parseFloat(similarities[index - 1].averageSimilarity) ? 'increasing' : 'decreasing') : 'initial',
    commonWords: sim.commonWords.length,
    uniqueWordsCount: {
      text1: sim.uniqueWords.text1.length,
      text2: sim.uniqueWords.text2.length
    }
  }));

  return {
    overallAverageSimilarity: averageSimilarity.toFixed(4),
    similarityTrend,
    consistencyScore: calculateConsistencyScore(similarityTrend),
    divergencePoints: findDivergencePoints(similarityTrend)
  };
}

function calculateConsistencyScore(similarityTrend) {
  const trends = similarityTrend.slice(1).map(item => item.trend);
  const increasingCount = trends.filter(trend => trend === 'increasing').length;
  const decreasingCount = trends.filter(trend => trend === 'decreasing').length;
  return Math.abs(increasingCount - decreasingCount) / trends.length;
}

function findDivergencePoints(similarityTrend) {
  const threshold = 0.1; // Możesz dostosować ten próg
  return similarityTrend.filter((item, index, array) => {
    if (index === 0) return false;
    return Math.abs(parseFloat(item.averageSimilarity) - parseFloat(array[index - 1].averageSimilarity)) > threshold;
  }).map(item => item.pairIndex);
}