import { franc } from 'franc';
import langs from 'langs';
import { tokenize } from './tokenizer';

export function detectLanguage(text, options = {}) {
  const {
    minConfidence = 0.5,
    allowedLanguages = null,
    fallbackLanguage = 'en'
  } = options;

  const tokens = tokenize(text, { removeStopwords: false, stem: false });
  const langCode = franc(tokens.join(' '), { 
    minLength: 10,
    only: allowedLanguages
  });

  if (langCode === 'und') {
    return {
      languageCode: fallbackLanguage,
      languageName: langs.where('1', fallbackLanguage).name,
      confidence: 0,
      isReliable: false
    };
  }

  const langInfo = langs.where('3', langCode);
  const confidence = calculateConfidence(text, langCode);

  return {
    languageCode: langInfo['1'],
    languageName: langInfo.name,
    confidence,
    isReliable: confidence >= minConfidence
  };
}

function calculateConfidence(text, detectedLangCode) {
  // To jest uproszczona implementacja. W rzeczywistości, można by użyć
  // bardziej zaawansowanych metod, np. porównując wyniki z kilku detektorów języka.
  const textLength = text.length;
  const baseConfidence = 0.3;
  const lengthFactor = Math.min(textLength / 100, 1);
  return baseConfidence + (1 - baseConfidence) * lengthFactor;
}

export function detectMultipleLanguages(text, options = {}) {
  const {
    minLength = 50,
    minConfidence = 0.3
  } = options;

  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  const languageSegments = [];

  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences.slice(i, i + 3).join(' ');
    if (segment.length < minLength) continue;

    const detection = detectLanguage(segment, { minConfidence });
    if (detection.isReliable) {
      languageSegments.push({
        text: segment,
        ...detection
      });
      i += 2;  // Skip the next two sentences as they were included in this segment
    }
  }

  return languageSegments;
}