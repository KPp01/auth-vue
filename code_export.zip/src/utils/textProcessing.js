import natural from 'natural';
import { tokenize } from './tokenizer';

const TfIdf = natural.TfIdf;
const stemmer = natural.PorterStemmer;

export function extractKeyPoints(text, options = { maxPoints: 5, minRelevance: 0.1 }) {
  const { maxPoints, minRelevance } = options;
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  const tfidf = new TfIdf();

  sentences.forEach(sentence => tfidf.addDocument(tokenize(sentence)));

  const keyPoints = sentences.map((sentence, index) => {
    const terms = tfidf.listTerms(index);
    const relevance = terms.reduce((sum, term) => sum + term.tfidf, 0) / terms.length;
    return { sentence: sentence.trim(), relevance };
  });

  return keyPoints
    .filter(point => point.relevance >= minRelevance)
    .sort((a, b) => b.relevance - a.relevance)
    .slice(0, maxPoints);
}

export function generateBulletPoints(keyPoints) {
  return keyPoints.map(point => `• ${point.sentence}`).join('\n');
}

export function summarizeText(text, options = { sentenceRatio: 0.3, minSentences: 3, maxSentences: 5 }) {
  const { sentenceRatio, minSentences, maxSentences } = options;
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
  const tfidf = new TfIdf();

  sentences.forEach(sentence => tfidf.addDocument(tokenize(sentence)));

  const rankedSentences = sentences.map((sentence, index) => {
    const terms = tfidf.listTerms(index);
    const score = terms.reduce((sum, term) => sum + term.tfidf, 0);
    return { sentence: sentence.trim(), score };
  }).sort((a, b) => b.score - a.score);

  const numSentences = Math.max(
    minSentences,
    Math.min(maxSentences, Math.round(sentences.length * sentenceRatio))
  );

  return rankedSentences.slice(0, numSentences).map(item => item.sentence).join(' ');
}

export function findNamedEntities(text) {
  const language = "EN";
  const tokenizer = new natural.WordTokenizer();
  const tokens = tokenizer.tokenize(text);
  const lexicon = new natural.Lexicon(language, stemmer);
  const ruleSet = new natural.RuleSet('EN');
  const tagger = new natural.BrillPOSTagger(lexicon, ruleSet);

  const taggedTokens = tagger.tag(tokens);

  const namedEntities = [];
  let currentEntity = [];

  taggedTokens.forEach((taggedToken, index) => {
    const [token, tag] = taggedToken;
    if (tag.startsWith('N') && token[0] === token[0].toUpperCase()) {
      currentEntity.push(token);
    } else {
      if (currentEntity.length > 0) {
        namedEntities.push(currentEntity.join(' '));
        currentEntity = [];
      }
    }
  });

  if (currentEntity.length > 0) {
    namedEntities.push(currentEntity.join(' '));
  }

  return [...new Set(namedEntities)];
}

export function generateWordCloud(text, options = { maxWords: 100, minOccurrences: 2 }) {
  const { maxWords, minOccurrences } = options;
  const tokens = tokenize(text, { removeStopwords: true, stem: true });
  const wordCounts = tokens.reduce((acc, token) => {
    acc[token] = (acc[token] || 0) + 1;
    return acc;
  }, {});

  return Object.entries(wordCounts)
    .filter(([_, count]) => count >= minOccurrences)
    .sort((a, b) => b[1] - a[1])
    .slice(0, maxWords)
    .map(([word, count]) => ({ text: word, value: count }));
}