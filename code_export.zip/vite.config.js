import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': '/src',
    }
  },
  define: {
    'process.env': {},  // Zdefiniowanie zmiennych środowiskowych
  },
  build: {
    rollupOptions: {
      external: [],  // Usuwamy tu elementy, aby nie wykluczać PrimeVue
    }
  }
});
