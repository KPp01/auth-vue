import OpenAI from 'openai';
import fs from 'fs/promises';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

// Inicjalizacja OpenAI z kluczem API
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Lista plików do przetworzenia
const filePaths = [
  'src/store/store.js',
  'src/App.vue',
  'src/firebase/notificationService.js',
  'src/style.css',
  'src/firebase.js',
  'src/components/UpdateProfile.vue',
  'src/components/Home.vue',
  'src/components/Dashboard.vue',
  'src/components/Login.vue',
  'src/components/AdminDashboard.vue',
  'src/components/orders/OrderLocation.vue',
  'src/components/orders/OrderTools.vue',
  'src/components/orders/OrderAttachments.vue',
  'src/components/orders/OrderNumber.vue',
  'src/components/orders/OrderMaterials.vue',
  'src/components/orders/OrdersList.vue',
  'src/components/orders/OrderEmployees.vue',
  'src/components/orders/OrderTasks.vue',
  'src/components/orders/StatusSelector.vue',
  'src/components/orders/OrderRemarks.vue',
  'src/components/orders/OrderForm.vue',
  'src/components/orders/Notifications.vue',
  'src/components/orders/OrderDetails.vue',
  'src/components/orders/OrderDashboard.vue',
  'src/components/NavigationBar.vue',
  'src/components/employees/WorkHours.vue',
  'src/components/Register.vue',
  'src/plugins/primevue.js',
  'src/assets/styles/orders.css',
  'src/auth/userService.js',
  'src/main.js',
  'src/logger.js',
  'src/modules/orders/orderStore.js',
  'src/modules/orders/orderValidation.js',
  'src/modules/orders/orderService.js',
  'src/router/index.js',
];

// Dozwolone rozszerzenia plików
const allowedExtensions = ['.js', '.vue', '.css', '.html', '.json'];

// Główna funkcja analizująca pliki
async function analyzeFiles() {
  try {
    for (const relativeFilePath of filePaths) {
      const filePath = path.join(process.cwd(), relativeFilePath);
      const ext = path.extname(filePath);

      // Sprawdź, czy rozszerzenie pliku jest dozwolone
      if (!allowedExtensions.includes(ext)) {
        console.log(`Pomijam plik ${filePath} (nieobsługiwane rozszerzenie)`);
        continue;
      }

      // Odczytaj zawartość pliku
      let fileContent;
      try {
        fileContent = await fs.readFile(filePath, 'utf-8');
      } catch (readError) {
        console.error(`Nie można odczytać pliku ${filePath}: ${readError.message}`);
        continue;
      }

      // Szacowanie liczby tokenów
      const estimatedTokens = Math.ceil(fileContent.length / 4);

      if (estimatedTokens > 3500) {
        console.warn(`Plik ${relativeFilePath} jest zbyt duży (${estimatedTokens} tokenów). Pomijam.`);
        continue;
      }

      // Utwórz zapytanie do modelu
      const completion = await openai.chat.completions.create({
        model: 'gpt-4', // Użycie modelu GPT-4 dla analizy
        messages: [
          {
            role: 'system',
            content: 'Jesteś doświadczonym programistą. Przeanalizuj poniższy kod pod kątem błędów i optymalizacji.',
          },
          {
            role: 'user',
            content: `Proszę, przeanalizuj plik ${relativeFilePath}:\n\n${fileContent}`,
          },
        ],
      });

      console.log(`\n=== Odpowiedź dla pliku ${relativeFilePath} ===\n`);
      console.log(completion.choices[0].message.content);
    }
  } catch (error) {
    console.error('Wystąpił błąd podczas analizy plików:', error.message);
  }
}

// Uruchom analizę
analyzeFiles();
